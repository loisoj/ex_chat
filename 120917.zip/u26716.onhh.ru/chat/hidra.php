<?php
file_put_contents('anytime.txt', $_POST['name']);
file_put_contents('anywhere.txt', $_POST['namex']);
