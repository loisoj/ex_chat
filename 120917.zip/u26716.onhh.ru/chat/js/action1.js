

$("#send_this").keyup(function(event){
  var gThis = $('#send_this').val();


$(document).ready(function(){

$.ajax({
   type: "POST",
   url: "hidra.php",
   data: {name: gThis},
   success: function(msg){
    // alert( "Данные успешно сохранены: " + msg );
   }
 });
 });
  });
$("body").on("keyup keydown mousemove", function(event){
 $( ".alertMSG" ).load( "anywhere.txt" );
});
