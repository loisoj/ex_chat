

$("#send_thisx").keyup(function(event){
  var gThisx = $('#send_thisx').val();


$(document).ready(function(){

$.ajax({
   type: "POST",
   url: "hidra.php",
   data: {namex: gThisx},
   success: function(msg){
    // alert( "Данные успешно сохранены: " + msg );
   }
 });
 });
  });
$("body").on("keyup keydown mousemove", function(event){
 $( ".alertMSGx" ).load( "anytime.txt" );
});

$("#clearx").click(function(event){
  $("#send_thisx").val('');
});
