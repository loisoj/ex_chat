<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
<script type="text/javascript" src="http://code.jquery.com/jquery-2.1.3.min.js"></script>
<script type="text/javascript" src="js/matrix.js"></script>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<script src="fingerprint.js"></script>

</head>
<body>
<!-- <canvas id="locoalien"></canvas> -->
<div class="alertMSG"></div>
<textarea id="send_this"> </textarea>
<!-- <a id="clear">Отчистить</a> -->


<script type="text/javascript" src="js/action1.js"></script>

<div class="alertMSGx"></div>
<textarea id="send_thisx"> </textarea>
<!-- <a id="clearx">Отчистить</a> -->


<script type="text/javascript" src="js/action2.js"></script>

<script>
// var result = history.length;
// alert(result);
// if(result != 0){
//   alert('Данный сайт будет работать только с выключенными куками(режим инкогнито), для Вашей же безопасности.');
//   location = "/";
// }</script>

<h1 id="fp1"></h1>

<script>
  var fp1 = new Fingerprint();
  document.getElementById('fp1').innerHTML = fp1.get();

  var testcan = document.getElementById('fp1').innerHTML;
  if(testcan){
alert('Привет Никита');
  //  location = "/";
  }
  else{
    location = "/";
  }
</script>

</body>
</html>
